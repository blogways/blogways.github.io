package net.blogways.jaxp.example;

import java.io.FileInputStream;

import javax.xml.parsers.SAXParserFactory;

import net.blogways.jaxp.example.handler.StaffHandler;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

public class SAXExample {

	public static void main(String[] args) throws Exception {
		
		SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware( true );
        
        XMLReader xmlReader = spf.newSAXParser().getXMLReader();
        
        xmlReader.setContentHandler(new StaffHandler());
        
        xmlReader.parse(new InputSource(new FileInputStream("staffs.xml")));
        
	}
	
}
