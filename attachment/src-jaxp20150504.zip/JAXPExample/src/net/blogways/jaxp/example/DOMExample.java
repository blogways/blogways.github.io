package net.blogways.jaxp.example;

import java.io.FileInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class DOMExample {

	public static void main(String[] args) throws Exception {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		DocumentBuilder builder = factory.newDocumentBuilder();

		Document document = builder.parse(new InputSource(new FileInputStream("staffs.xml")));
		
		forEachNode(document);
	}
	
	private static void forEachNode(Document doc) {
		NodeList nodeList =  doc.getDocumentElement().getChildNodes();
		
		for(int i=0; i<nodeList.getLength(); ++i) {
			Node staff = nodeList.item(i);
			if (staff instanceof Element) {
				NodeList props = staff.getChildNodes();
				
				for (int j=0; j<props.getLength(); ++j) {
					Node prop = props.item(j) ;
					if (prop instanceof Element) {
						String content = prop.getLastChild().getTextContent().trim();
						switch(prop.getNodeName()) {
						case "firstname": 
							System.out.println("firstname:"+content);
							break;
						case "lastname":
							System.out.println("lastname:"+content);
							break;
						case "nickname":
							System.out.println("nickname:"+content);
							break;
						case "salary":
							System.out.println("salary:"+content);
							break;
						}
					}
				}
				
				System.out.println();
			}
		}
	}

}
